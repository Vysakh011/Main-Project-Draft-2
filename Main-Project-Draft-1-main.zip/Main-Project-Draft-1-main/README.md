# Main-Project-Draft-1
This is the test for app draft 1


// format :plug:1 voltage:234V current:0.05A
